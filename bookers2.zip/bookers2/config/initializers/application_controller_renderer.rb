# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '589cfa8ad747e310d1fd4682820cf7ee8b1bd41df44036b43c66484d86a8d1ea854f8bbfa5ca89c2dc51ae6bf2bebe8326de0c4e4d08e3d49c6e393cd13ca2b8'